package com.SpringBoot.MSM.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.MSM.model.Purchase;

public interface PurchaseRepository extends JpaRepository<Purchase,Integer>{

}
