package com.SpringBoot.MSM.service;

import java.util.List;

import com.SpringBoot.MSM.model.Purchase;

public interface PurchaseService {
	public Purchase savePurchase(Purchase purchase);
	public List<Purchase> getAllPurchase();
	public Purchase getPurchaseById(Integer id);
	public String deletePurchase(Integer id);
	public void update(Purchase purchase);
	public void add(Purchase purchase);
}
