package com.SpringBoot.MSM.model;

import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="medicines")
public class Medicines {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Med_id;
	private String Med_name;
	private String Category;
	private int Med_qty;
	private int Med_priceperone;
	public int getMed_id() {
		return Med_id;
	}
	public String getMed_name() {
		return Med_name;
	}
	public String getCategory() {
		return Category;
	}
	public int getMed_qty() {
		return Med_qty;
	}
	public int getMed_priceperone() {
		return Med_priceperone;
	}
	public void setMed_id(int med_id) {
		Med_id = med_id;
	}
	public void setMed_name(String med_name) {
		Med_name = med_name;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public void setMed_qty(int med_qty) {
		Med_qty = med_qty;
	}
	public void setMed_priceperone(int med_priceperone) {
		Med_priceperone = med_priceperone;
	}
	
	
}
