package com.SpringBoot.MSM.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.model.Customer;
import com.SpringBoot.MSM.model.Login;
import com.SpringBoot.MSM.repository.CustomerRepository;
@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository customerRepo;

	@Override
	public Customer saveCustomer(Customer customer) {
		
		return customerRepo.save(customer);
	}

	@Override
	public List<Customer> getAllCustomer() {
		
		return customerRepo.findAll();
	}

	@Override
	public Customer getCustomerById(Integer id) {
		
		return customerRepo.findById(id).get();
	}

	@Override
	public String deleteCustomer(Integer id) {
		Customer customer=customerRepo.findById(id).get();
		if(customer!=null) {
			customerRepo.delete(customer);
			return "Customer is deleted successfully";
		}
		return "Something went wrong";
	}

	@Override
	public void update(Customer customer) {
		customerRepo.save(customer);
	}

	@Override
	public List<Customer> getCustomerByMail(String mail) {
		// TODO Auto-generated method stub
		 //List<Customer> cust = customerRepo.findAll();
		 List<Customer> cust = customerRepo.findAll();
		 /*System.out.println(cust);
		 System.out.println("Cust Mail "+mail);*/
		
		System.out.println("hello");
		 
		 return cust ;
	}
	@Override
	public ArrayList<Customer> getAllCustomer1(Login loginInfo) {
		List<Customer> cust = customerRepo.findAll();
		ArrayList<Customer> res = new ArrayList<>();
		for(Customer x:cust) {
			
			if(x.getMail().equals(loginInfo.getMail()) && x.getPassword().equals(loginInfo.getPassword())) {
				res.add(x);
				return res;
			}
		}
		return null;
	}
	/*@Override
	public void add(Customer customer) {
		customerRepo.save(customer);
		
	}*/

	

}
