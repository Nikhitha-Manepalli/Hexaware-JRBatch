package com.SpringBoot.MSM.model;

import java.math.BigDecimal;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="purchase")
public class Purchase {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int purchase_id;
	private String item_name;
	private int quantity;
	private BigDecimal price_per_unit;
	private BigDecimal total_cost;
	private String purchase_date;
	public int getPurchase_id() {
		return purchase_id;
	}
	public String getItem_name() {
		return item_name;
	}
	public int getQuantity() {
		return quantity;
	}
	public BigDecimal getPrice_per_unit() {
		return price_per_unit;
	}
	public BigDecimal getTotal_cost() {
		return total_cost;
	}
	public void setPurchase_id(int purchase_id) {
		this.purchase_id = purchase_id;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setPrice_per_unit(BigDecimal price_per_unit) {
		this.price_per_unit = price_per_unit;
	}
	public void setTotal_cost(BigDecimal total_cost) {
		this.total_cost = total_cost;
	}
	public String getPurchase_date() {
		return purchase_date;
	}
	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}
	
}
