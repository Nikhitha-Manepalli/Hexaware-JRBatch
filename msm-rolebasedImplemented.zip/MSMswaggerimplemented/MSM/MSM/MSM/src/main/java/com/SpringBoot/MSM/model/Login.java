package com.SpringBoot.MSM.model;

public class Login {
	private String Password;
	private String Mail;
	public String getPassword() {
		return Password;
	}
	public String getMail() {
		return Mail;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public void setMail(String mail) {
		Mail = mail;
	}
}
