package com.SpringBoot.MSM.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.Exception.ResourceNotFoundException;
import com.SpringBoot.MSM.model.Category;
import com.SpringBoot.MSM.model.Product;
import com.SpringBoot.MSM.model.User;
import com.SpringBoot.MSM.payload.CategoryDto;
import com.SpringBoot.MSM.payload.ProductDto;
import com.SpringBoot.MSM.payload.UserDto;
import com.SpringBoot.MSM.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
  public UserDto createUser(UserDto userDto) {
	 	  //userdto to user
	  User user=this.mapper.map(userDto,User.class);
	  String pass=user.getPassword();
	  String encode = this.passwordEncoder.encode(pass);
	  user.setPassword(encode);
	  //save
	 User saveUser = this.userRepo.save(user);
	 //user to userdto
	 UserDto saveUserDto = this.mapper.map(saveUser, UserDto.class);
	  return saveUserDto ;
  }
  /* public UserDto getById(int userId) {
   User findByuserId = this.userRepo.findByuserId(userId);
   UserDto userDto = this.mapper.map(findByuserId,UserDto.class);
    return userDto;
  }*/
  public UserDto getbyId(int userId) {
		User getByid = this.userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("This user id not found"));

		return this.mapper.map(getByid,UserDto.class);
	}
  

   public void deleteUser(int userId) {
	   User byId = this.userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException(+userId+" user not found"));
	  // this.userRepo.delete(findById);
		userRepo.delete(byId);	

   }
   public List<UserDto>findAllUser(){
	   List<User> findAll=this.userRepo.findAll();
	   //user->userdto
	   List<UserDto> collect = findAll.stream().map(each ->this.mapper.map(each, UserDto.class)).collect(Collectors.toList());	   
	   
	   return collect;
	   
   }
   
}
