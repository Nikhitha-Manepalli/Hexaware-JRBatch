package com.SpringBoot.MSM.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.MSM.model.Cart;
import com.SpringBoot.MSM.model.User;

public interface CartRepository extends JpaRepository<Cart,Integer>{

	Cart findByUser(User user);
	//public Optional<Cart>findByUserAndcartId(int cartId);

}
