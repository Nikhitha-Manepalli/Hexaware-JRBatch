package com.SpringBoot.MSM.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.MSM.model.Category;
import com.SpringBoot.MSM.model.Product;

public interface CategoryRepository extends JpaRepository<Category,Integer> {

}
