package com.SpringBoot.MSM.service;

import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.Exception.ResourceNotFoundException;
import com.SpringBoot.MSM.model.Cart;
import com.SpringBoot.MSM.model.CartItem;
import com.SpringBoot.MSM.model.Product;
import com.SpringBoot.MSM.model.User;
import com.SpringBoot.MSM.payload.CartDto;
import com.SpringBoot.MSM.payload.ItemRequest;
import com.SpringBoot.MSM.repository.CartRepository;
import com.SpringBoot.MSM.repository.ProductRepository;
import com.SpringBoot.MSM.repository.UserRepository;

@Service
public class CartService {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private ProductRepository productRepo;
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private ModelMapper modelMapper;
	
	public CartDto addItem(ItemRequest item,String username) {
		int productId=item.getProductId();
		int quantity=item.getQuantity();
		//fetch user
		User user = this.userRepo.findByemail(username).orElseThrow(()->new ResourceNotFoundException("user not found"));
		System.out.println("hi");

		//fetch product
		 Product product=this.productRepo.findById(productId).orElseThrow(()->new ResourceNotFoundException("Product not found"));
		 //here we are checking product stock
		if(!product.isStock()) {
			
			new ResourceNotFoundException("product out of stock");
		}
		//create cartitem with productId and qnt
		CartItem cartItem=new CartItem();
		cartItem.setProduct(product);
		cartItem.setQuantity(quantity);
		double totalprice=product.getProductPrize()*quantity;
		cartItem.setTotalPrice(totalprice);
		
		//getting cart from user

		Cart cart=user.getCart();
		if(cart==null) {
			cart=new Cart();
			//
			cart.setUser(user);
			
		}
		cartItem.setCart(cart);
		Set<CartItem> items=cart.getItems();

		//here we check item is available in cartitem or not
		//if cartitem is available then we increasee qnt only else
		//add new product in cartitem
		//by default false
		AtomicReference<Boolean> flag=new AtomicReference<>(false);
		Set<CartItem> newproduct = items.stream().map((i)->{
			if(i.getProduct().getProductId()==product.getProductId()) {
				i.setQuantity(quantity);
				i.setTotalPrice(totalprice);
				flag.set(true);
			}
			return i;
		}).collect(Collectors.toSet());
		if(flag.get()) {
			items.clear();
			items.addAll(newproduct);
		}else {
			cartItem.setCart(cart);
			items.add(cartItem);
			
		}
		
		Cart saveCart = this.cartRepo.save(cart);
		
		return this.modelMapper.map(saveCart, CartDto.class);
	}
	public CartDto getcartAll(String email) {
		
		//find user
		User user = this.userRepo.findByemail(email).orElseThrow(()->new ResourceNotFoundException("User not found"));
		//find cart 
		//C cart = this.cartRepo.findByUser(user).orElseThrow(()->new ResourceNotFoundException("There is no cart"));
	 Cart cart = this.cartRepo.findByUser(user);
		return this.modelMapper.map(cart, CartDto.class);
	}
	//get cart by cartid
	public CartDto getCartByID(int cartId) {
		Cart findByUserAndcarttId = this.cartRepo.findById(cartId).orElseThrow(()->new ResourceNotFoundException("cart not found"));
		
		return this.modelMapper.map(findByUserAndcarttId, CartDto.class);
	}
	public CartDto removeCartItemFromCart(String userName,int ProductId) {
		User user = this.userRepo.findByemail(userName).orElseThrow(()->new ResourceNotFoundException("User not found"));
		Cart cart=user.getCart();
		Set<CartItem> items = cart.getItems();
		boolean removeIf = items.removeIf((i)->i.getProduct().getProductId()==ProductId);
		Cart save = this.cartRepo.save(cart);
		return this.modelMapper.map(save, CartDto.class);
	}

	
	

}
