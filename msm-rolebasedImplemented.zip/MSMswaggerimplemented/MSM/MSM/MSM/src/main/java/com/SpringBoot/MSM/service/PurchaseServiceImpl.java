package com.SpringBoot.MSM.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.SpringBoot.MSM.model.Purchase;
import com.SpringBoot.MSM.repository.PurchaseRepository;
@Service
public class PurchaseServiceImpl implements PurchaseService {
	@Autowired
	private PurchaseRepository purchaseRepo;

	@Override
	public Purchase savePurchase(Purchase purchase) {
		
		return purchaseRepo.save(purchase);
	}

	@Override
	public List<Purchase> getAllPurchase() {
		return purchaseRepo.findAll();
	}

	@Override
	public Purchase getPurchaseById(Integer id) {
		return purchaseRepo.findById(id).get();
	}

	@Override
	public String deletePurchase(Integer id) {
		Purchase purchase=purchaseRepo.findById(id).get();
		if(purchase!=null) {
			purchaseRepo.delete(purchase);
			return "Purchase is deleted successfully";
		}
		return "Something went wrong";
	}

	@Override
	public void update(Purchase purchase) {
		purchaseRepo.save(purchase);
	}

	@Override
	public void add(Purchase purchase) {
		purchaseRepo.save(purchase);
	}

}
