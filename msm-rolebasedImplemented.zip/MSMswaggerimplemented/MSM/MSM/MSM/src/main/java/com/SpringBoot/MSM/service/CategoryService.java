package com.SpringBoot.MSM.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.Exception.ResourceNotFoundException;
import com.SpringBoot.MSM.model.Category;
import com.SpringBoot.MSM.payload.CategoryDto;
import com.SpringBoot.MSM.repository.CategoryRepository;

@Service
public class CategoryService {
	@Autowired
	private CategoryRepository catRepo;
	@Autowired
	private ModelMapper mapper;
	public CategoryDto create(CategoryDto dto) {
		//categoryDto to category
		Category cat = this.mapper.map(dto,Category.class);
		Category save = this.catRepo.save(cat);
		//category to categoryDto
		return this.mapper.map(save, CategoryDto.class);
		
	}
	public CategoryDto update(CategoryDto newcat, int catid) {
		Category oldCat = this.catRepo.findById(catid).orElseThrow(()->new ResourceNotFoundException("This Category id not found"));
		oldCat.setTitle(newcat.getTitle());
		Category save=this.catRepo.save(oldCat);
		
		return this.mapper.map(save, CategoryDto.class);
	}
	public void delete(int catid) {
		Category Cat = this.catRepo.findById(catid).orElseThrow(()->new ResourceNotFoundException("This Category id not found"));
		this.catRepo.delete(Cat);

		
	}
	public CategoryDto getbyId(int catid) {
		Category getByid = this.catRepo.findById(catid).orElseThrow(()->new ResourceNotFoundException("This Category id not found"));

		return this.mapper.map(getByid,CategoryDto.class);
	}
	public List<CategoryDto> getAll(){
		List<Category>findAll=this.catRepo.findAll();
		List<CategoryDto> allDto = findAll.stream().map(cat->this.mapper.map(cat, CategoryDto.class)).collect(Collectors.toList());
		return allDto;
	}
	

}
