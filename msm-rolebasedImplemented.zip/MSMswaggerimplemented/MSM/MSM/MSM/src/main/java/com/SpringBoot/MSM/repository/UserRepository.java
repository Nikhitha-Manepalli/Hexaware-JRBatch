package com.SpringBoot.MSM.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.MSM.model.User;

public interface UserRepository extends JpaRepository<User,Integer>{
	//User findByuserId(int userId);
	Optional<User>findByemail(String email);

}
