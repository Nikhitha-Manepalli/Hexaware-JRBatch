package com.SpringBoot.MSM.service;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.Exception.ResourceNotFoundException;
import com.SpringBoot.MSM.model.Cart;
import com.SpringBoot.MSM.model.CartItem;
import com.SpringBoot.MSM.model.Order;
import com.SpringBoot.MSM.model.OrderItem;
import com.SpringBoot.MSM.model.User;
import com.SpringBoot.MSM.payload.OrderDto;
import com.SpringBoot.MSM.payload.OrderRequest;
import com.SpringBoot.MSM.payload.OrderResponse;
import com.SpringBoot.MSM.repository.CartRepository;
import com.SpringBoot.MSM.repository.OrderRepository;
import com.SpringBoot.MSM.repository.UserRepository;

@Service
public class OrderService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private OrderRepository  orderRepo;
	//order create  method
	
	public OrderDto orderCreate(OrderRequest request,String username) {
		
	
		User user = this.userRepo.findByemail(username).orElseThrow(()->new ResourceNotFoundException("User not found"));
		int cartId=request.getCartId();
		String orderAddress=request.getOrderAddress();		
		//find cart
		Cart cart = this.cartRepo.findById(cartId).orElseThrow(()->new ResourceNotFoundException("cart not found"));
		//getting cartitem
		Set<CartItem> items=cart.getItems();
		Order order=new Order();
		AtomicReference<Double> totalOrderPrice=new AtomicReference<Double>(0.0);
		Set<OrderItem>orderitems=items.stream().map((cartItem)->{
			OrderItem orderItem=new OrderItem();
			//set cartitem into orderitem
			
			//set product in orderitem
			orderItem.setProduct(cartItem.getProduct());
			//set productqty in orderitem
			orderItem.setProductQuantity(cartItem.getQuantity());
			orderItem.setTotalProductprice(cartItem.getTotalPrice());
			orderItem.setOrder(order);
			totalOrderPrice.set(totalOrderPrice.get()+orderItem.getTotalProductprice());
			int productId=orderItem.getProduct().getProductId();
			return orderItem;
		}).collect(Collectors.toSet());
		
		order.setBillingAddress(orderAddress);
		order.setOrderDelivered(null);
		order.setOrderStatus("CREATED");
		order.setPaymentStatus("Not PAID");
		order.setUser(user);
		order.setOrderItem(orderitems);
		order.setOrderAmt(totalOrderPrice.get());
		order.setOrderCreateAt(new Date());
		Order save;
		if(order.getOrderAmt()>0){
			save = this.orderRepo.save(order);
			cart.getItems().clear();
			 this.cartRepo.save(cart);
			System.out.println("Hello");
		}else {
			System.out.println(order.getOrderAmt());
			throw new ResourceNotFoundException("plz Add Cart first and place order");
		}
		
		
		return this.modelMapper.map(save ,OrderDto.class);
	}
	
	
	public void CancelOrder(int orderId) {
		Order order = this.orderRepo.findById(orderId).orElseThrow(()->new ResourceNotFoundException("Order not found"));
		this.orderRepo.delete(order);
		
	}
	public OrderDto findById(int orderId) {
		Order order = this.orderRepo.findById(orderId).orElseThrow(()->new ResourceNotFoundException("Order not found"));
		
		return this.modelMapper.map(order, OrderDto.class);
	}
	//find All product by page
	public OrderResponse findAllOrders(int pageNumber,int pageSize) {
		Pageable pageable=PageRequest.of(pageNumber, pageSize);
		Page<Order>findAll=this.orderRepo.findAll(pageable);
		List<Order>content=findAll.getContent();
		//change order to orderdto
		List<OrderDto>collect=content.stream().map((each)->this.modelMapper.map(each,OrderDto.class)).collect(Collectors.toList());
		
		OrderResponse response=new OrderResponse();
		response.setContent(collect);
		response.setPageNumber(findAll.getNumber());
		response.setLastPage(findAll.isLast());
		response.setPageSize(findAll.getSize());
		response.setTotalPage(findAll.getTotalPages());
		response.setTotalElement(findAll.getTotalElements());
		
		return response;
		
		
	}

}
