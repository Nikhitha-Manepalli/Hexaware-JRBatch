package com.SpringBoot.MSM.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.SpringBoot.MSM.model.Purchase;
import com.SpringBoot.MSM.service.PurchaseService;

@RestController
@RequestMapping
@CrossOrigin(origins = "http://localhost:3000")
public class PurchaseController {
	@Autowired
	private PurchaseService purchaseService;
	@PostMapping("/savePurchase")
	public ResponseEntity<?> savePurchase(@RequestBody Purchase purchase)
	{
		return new ResponseEntity<>(purchaseService.savePurchase(purchase), HttpStatus.CREATED);
	}
	@GetMapping("/viewPurchase")
	public ResponseEntity<?> getAllPurchase()
	{
		return new ResponseEntity<>(purchaseService.getAllPurchase(),HttpStatus.OK);
	}
	@GetMapping("/purchase/{id}")
	public ResponseEntity<?> getPurchaseById(@PathVariable Integer id)
	{
		return new ResponseEntity<>(purchaseService.getPurchaseById(id),HttpStatus.OK);
	}
	@GetMapping("/deletePurchase/{id}")
	public ResponseEntity<?> deletePurchase(@PathVariable Integer id)
	{
		return new ResponseEntity<>(purchaseService.deletePurchase(id), HttpStatus.OK);
	}
	@PostMapping("/addPurchase")
	public void addCustomer(@RequestBody Purchase purchase)
	{
		purchaseService.savePurchase(purchase);
	}
	@PutMapping("/updatePurchase/{id}")
	public void updateCustomer(@PathVariable Integer id,@RequestBody Purchase purchase)
	{
		purchaseService.savePurchase(purchase);
	}
}
