package com.SpringBoot.MSM.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.MSM.model.Customer;
import com.SpringBoot.MSM.model.Login;
import com.SpringBoot.MSM.service.CustomerService;

@RestController
@RequestMapping
@CrossOrigin(origins = "http://localhost:3000")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/saveCustomer")
	public ResponseEntity<?> saveCustomer(@RequestBody Customer customer)
	{
		return new ResponseEntity<>(customerService.saveCustomer(customer), HttpStatus.CREATED);
		
	}
	@GetMapping("/viewCustomer")
	public ResponseEntity<?> getAllCustomer()
	{
		return new ResponseEntity<>(customerService.getAllCustomer(),HttpStatus.OK);
	}
	@GetMapping("/customer/{id}")
	public ResponseEntity<?> getCustomerById(@PathVariable Integer id)
	{
		return new ResponseEntity<>(customerService.getCustomerById(id),HttpStatus.OK);
	}
	@GetMapping("/delete/{id}")
	public ResponseEntity<?> deleteCustomer(@PathVariable Integer id)
	{
		return new ResponseEntity<>(customerService.deleteCustomer(id), HttpStatus.OK);
	}
	@PostMapping("/addCustomer")
	public void addCustomer(@RequestBody Customer customer)
	{
		customerService.saveCustomer(customer);
	}
	@PutMapping("/updateCustomer/{id}")
	public void updateCustomer(@PathVariable Integer id,@RequestBody Customer customer)
	{
		customerService.saveCustomer(customer);
	}
	@PostMapping("/login")
	public ResponseEntity<?> getAllCustomer1(@RequestBody Login loginInfo)
	{
		
		System.out.print(loginInfo.getMail());
		return new ResponseEntity<>(customerService.getAllCustomer1(loginInfo),HttpStatus.OK);
	}

}
