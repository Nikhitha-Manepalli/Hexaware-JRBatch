package com.SpringBoot.MSM.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.MSM.model.Category;
import com.SpringBoot.MSM.model.Product;
import com.SpringBoot.MSM.payload.CategoryDto;

public interface ProductRepository extends JpaRepository<Product,Integer> {
	List<Product> findByCategory(Category category);
	//Product setCategory(CategoryDto catDto);



}
