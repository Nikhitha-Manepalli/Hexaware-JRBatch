package com.SpringBoot.MSM.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.MSM.model.Medicines;
import com.SpringBoot.MSM.service.MedicinesService;

@RestController
@RequestMapping
@CrossOrigin(origins = "http://localhost:3000")
public class MedicinesController {
	
	@Autowired
	private MedicinesService medicinesService;
	@PostMapping("/saveMedicines")
	public ResponseEntity<?> saveMedicines(@RequestBody Medicines medicines)
	{
		return new ResponseEntity<>(medicinesService.saveMedicines(medicines), HttpStatus.CREATED);
	}
	@GetMapping("/viewMedicines")
	public ResponseEntity<?> getAllMedicines()
	{
		return new ResponseEntity<>(medicinesService.getAllMedicines(),HttpStatus.OK);
	}
	 @GetMapping("/Medicines/{id}")
	public ResponseEntity<?> getMedicinesById(@PathVariable Integer id)
	{
		return new ResponseEntity<>(medicinesService.getMedicinesById(id),HttpStatus.OK);
	}
	@GetMapping("/deleteMedicines/{id}")
	public ResponseEntity<?> deleteMedicines(@PathVariable Integer id)
	{
		return new ResponseEntity<>(medicinesService.deleteMedicines(id), HttpStatus.OK);
	}
	@PostMapping("/addMedicines")
	public void addCustomer(@RequestBody Medicines medicines)
	{
		medicinesService.add(medicines);
	}
	@PostMapping("/updateMedicines/{id}")
	public void updateCustomer(@PathVariable Integer id,@RequestBody Medicines medicines)
	{
		medicinesService.update(medicines);
	}
}
