package com.SpringBoot.MSM.service;

import java.util.ArrayList;
import java.util.List;

import com.SpringBoot.MSM.model.Customer;
import com.SpringBoot.MSM.model.Login;

public interface CustomerService {
	public Customer saveCustomer(Customer customer);
	public List<Customer> getAllCustomer();
	public Customer getCustomerById(Integer id);
	public String deleteCustomer(Integer id);
	public void update(Customer customer);
	//public void add(Customer customer);
	public List<Customer> getCustomerByMail(String mail);
	public ArrayList<Customer> getAllCustomer1(Login loginInfo);
	
}
