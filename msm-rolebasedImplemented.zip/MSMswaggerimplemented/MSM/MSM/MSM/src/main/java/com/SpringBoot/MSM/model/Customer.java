package com.SpringBoot.MSM.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;




@Entity
@Table(name="customer")

public class Customer {
	@Id
	// @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String Password;
	private String Firstname;
	private String Lastname;
	private int Age;
	private String Sex;
	private String Phno;
	private String Mail;
	public int getId() {
		return id;
	}
	public String getPassword() {
		return Password;
	}
	public String getFirstname() {
		return Firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public int getAge() {
		return Age;
	}
	public String getSex() {
		return Sex;
	}
	public String getMail() {
		return Mail;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public void setAge(int age) {
		Age = age;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public void setMail(String mail) {
		Mail = mail;
	}
	public String getPhno() {
		return Phno;
	}
	public void setPhno(String phno) {
		Phno = phno;
	}
	

}
