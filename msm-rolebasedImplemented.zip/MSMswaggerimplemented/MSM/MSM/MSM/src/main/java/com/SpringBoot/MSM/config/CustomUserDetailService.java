package com.SpringBoot.MSM.config;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.Exception.ResourceNotFoundException;
import com.SpringBoot.MSM.model.User;
import com.SpringBoot.MSM.repository.UserRepository;

@Service
public class CustomUserDetailService implements UserDetailsService {
	@Autowired
	private UserRepository userRepo;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = this.userRepo.findByemail(email).orElseThrow(()->new ResourceNotFoundException("User not found"));
		return user;
	}

}
