package com.SpringBoot.MSM.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.model.Medicines;
import com.SpringBoot.MSM.repository.MedicinesRepository;
@Service
public class MedicinesServiceImpl implements MedicinesService{
	@Autowired
	private MedicinesRepository medicinesRepo;

	@Override
	public Medicines saveMedicines(Medicines medicines) {
		return medicinesRepo.save(medicines);
	}

	@Override
	public List<Medicines> getAllMedicines() {
		return medicinesRepo.findAll();
	}

	@Override
	public Medicines getMedicinesById(Integer id) {
		return medicinesRepo.findById(id).get();
	}

	@Override
	public String deleteMedicines(Integer id) {
		Medicines medicines=medicinesRepo.findById(id).get();
		if(medicines!=null) {
			medicinesRepo.delete(medicines);
			return " Medicines is deleted successfully";
		}
		return "Something went wrong";
	}

	@Override
	public void update(Medicines medicines) {
		medicinesRepo.save(medicines);
	}

	@Override
	public void add(Medicines medicines) {
		medicinesRepo.save(medicines);
	}

}
