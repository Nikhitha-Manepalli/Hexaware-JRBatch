package com.SpringBoot.MSM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.MSM.payload.ApiResponse;
import com.SpringBoot.MSM.payload.CategoryDto;
import com.SpringBoot.MSM.service.CategoryService;

@RestController
@RequestMapping("/categories")

public class CategoryController {
	@Autowired
	private CategoryService catService;
	//create category
	@PostMapping("/create")
	public ResponseEntity<CategoryDto>create(@RequestBody CategoryDto catDto){
		CategoryDto create=this.catService.create(catDto);
		return new ResponseEntity<CategoryDto>(create,HttpStatus.CREATED);
	}
	//update category
	@PostMapping("/update/{catid}")
	public ResponseEntity<CategoryDto>update( @RequestBody CategoryDto catDto,@PathVariable int catid){
		CategoryDto update=this.catService.update(catDto,catid);
		return new ResponseEntity<CategoryDto>(update,HttpStatus.OK);
	}
	
	//delete category
	@DeleteMapping("/delete/{catId}")
	public ResponseEntity<ApiResponse>delete(@PathVariable int catId){
		this.catService.delete(catId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Category deleted successfully",true),HttpStatus.OK);
	}
	//getcategorybyid
	@GetMapping("/getByid/{catId}")
	public ResponseEntity<CategoryDto>getByid(@PathVariable int catId){
		CategoryDto getbyId = this.catService.getbyId(catId);
		return new ResponseEntity<CategoryDto>(getbyId,HttpStatus.OK);
	}
	//get all category
	@GetMapping("/getAll")
	public ResponseEntity<List<CategoryDto>>getAll(){
		List<CategoryDto> all = this.catService.getAll();
		return new ResponseEntity<List<CategoryDto>>(all,HttpStatus.OK);
		}
	

}
