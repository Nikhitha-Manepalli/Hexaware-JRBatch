package com.SpringBoot.MSM.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.SpringBoot.MSM.Exception.ResourceNotFoundException;
import com.SpringBoot.MSM.model.Category;
import com.SpringBoot.MSM.model.Product;
import com.SpringBoot.MSM.payload.CategoryDto;
import com.SpringBoot.MSM.payload.ProductDto;
import com.SpringBoot.MSM.payload.ProductResponse;
import com.SpringBoot.MSM.repository.CategoryRepository;
import com.SpringBoot.MSM.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepo;
	@Autowired
	private CategoryRepository catRepo;
	@Autowired
	private ModelMapper mapper;
	

	public ProductDto createProduct(ProductDto productDto,int catid) {
		//fetch cat is available are not
	 Category cat = this.catRepo.findById(catid).orElseThrow(()->new ResourceNotFoundException("this category id not found on category"));
		//productdto to product
		Product product=toEntity(productDto);
		product.setCategory(cat);
		//save product in database
		System.out.print("hiii");
		Product save = this.productRepo.save(product);
		
		//product to productdto
		ProductDto dto=toDto(save);
		return dto;
	}
	

	public ProductResponse viewAll(int pageNumber,int pageSize,String sortBy,String sortDir) {
		Sort sort=null;
		if(sortDir.trim().toLowerCase().equals("asc")) {
			sort=sort.by(sortBy).ascending();
			System.out.print(sort);
			
		}else {
			sort=sort.by(sortBy).descending();
			System.out.print(sort);

		}
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<Product> page = this.productRepo.findAll(pageable);
		List<Product>pageProduct=page.getContent();
		//List<Product> product = pageProduct.stream().filter(p->p.isLive()).collect(Collectors.toList());
		List<ProductDto> productDto = pageProduct.stream().map(p->this.toDto(p)).collect(Collectors.toList());
		ProductResponse response=new ProductResponse();
		response.setContent(productDto);
		response.setPageNumber(page.getNumber());
		response.setPageSize(page.getSize());
		response.setTotalPages(page.getTotalPages());
		response.setLastPage(page.isLast());
		//productdto to product
		//List<Product>findAll=productRepo.findAll();
		//List<ProductDto>findAllDto=findAll.stream().map(product ->this.toDto(product)).collect(Collectors.toList());
		return response;
	}
	public ProductDto viewProductById(int pid) {
		Product findById=productRepo.findById(pid).orElseThrow(()->new ResourceNotFoundException(+pid+" from this product id product not found"));
		ProductDto dto=this.toDto(findById);
		return dto;
	}

	public void deleteProduct(int pid) {
		Product byId=productRepo.findById(pid).orElseThrow(()->new ResourceNotFoundException(+pid+" from this product id product not found")); 
				productRepo.delete(byId);

	}

	public ProductDto updateProduct(int pid,ProductDto newp) {
		Product oldp=productRepo.findById(pid).orElseThrow(()->new ResourceNotFoundException(+pid+" from this product id product not found"));
		oldp.setImageName(newp.getProductName());
		oldp.setLive(newp.isLive());
		oldp.setStock(newp.isStock());
		oldp.setProductPrize(newp.getProductPrize());
		oldp.setImageName(newp.getImageName());
		oldp.setProductQuantity(newp.getProductQuantity());
		Product save=productRepo.save(oldp);
		ProductDto dto=toDto(save);
		
		return dto;
	}
	//find product by Category
	public List<Product>findProductByCategory(int catId){
		Category Cat = this.catRepo.findById(catId).orElseThrow(()->new ResourceNotFoundException("this id not found"));
		List<Product> findByCategory = this.productRepo.findByCategory(Cat);
		return findByCategory;
	}
	//productdto to product
	public Product toEntity(ProductDto pDto) {
		Product p=new Product();
		p.setProductName(pDto.getProductName());
		p.setProductId(pDto.getProductId());
		p.setProductDesc(pDto.getProductDesc());
		p.setProductPrize(pDto.getProductPrize());
		p.setProductQuantity(pDto.getProductQuantity());
		p.setImageName(pDto.getImageName());
		p.setLive(pDto.isLive());
		p.setStock(pDto.isStock());
		return p;
		
		//return this.mapper.map(pDto,  Product.class);
	}
	//product to productdto
	public ProductDto toDto(Product product) {
		ProductDto pDto=new ProductDto();
		pDto.setProductId(product.getProductId());
		pDto.setImageName(product.getImageName());
		pDto.setProductName(product.getProductName());
		pDto.setProductDesc(product.getProductDesc());
		pDto.setProductPrize(product.getProductPrize());
		pDto.setProductQuantity(product.getProductQuantity());
		pDto.setLive(product.isLive());
		pDto.setStock(product.isStock());
		
		
		//change category to categorydto
		/*CategoryDto catDto=new CategoryDto();
		catDto.setCategoryId(product.getCategory().getCategoryId());
		catDto.setTitle(product.getCategory().getTitle());
		
		
		//System.out.println("Hi");
		pDto.setCategory(catDto);*/
		
		return pDto;
		
		
	}

	public ProductDto getProduct(int productId) {
		// TODO Auto-generated method stub
		Product product=this.productRepo.findById(productId).orElseThrow(()->new ResourceNotFoundException("produtc not found"));
		return this.mapper.map(product, ProductDto.class);
		
	}

	
	

}
