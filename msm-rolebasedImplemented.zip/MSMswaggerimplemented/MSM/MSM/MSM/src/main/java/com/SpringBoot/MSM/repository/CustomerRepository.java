package com.SpringBoot.MSM.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.MSM.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Integer> {

}
