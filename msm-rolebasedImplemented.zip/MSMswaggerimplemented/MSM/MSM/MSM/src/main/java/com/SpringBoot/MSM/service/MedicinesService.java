package com.SpringBoot.MSM.service;

import java.util.List;

import com.SpringBoot.MSM.model.Medicines;

public interface MedicinesService {
	public  Medicines saveMedicines( Medicines medicines);
	public List< Medicines> getAllMedicines();
	public  Medicines getMedicinesById(Integer id);
	public String deleteMedicines(Integer id);
	public void update(Medicines medicines);
	public void add( Medicines medicines);
}
