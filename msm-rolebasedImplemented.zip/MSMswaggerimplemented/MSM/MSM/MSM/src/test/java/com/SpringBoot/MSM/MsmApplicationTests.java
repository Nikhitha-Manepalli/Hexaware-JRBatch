package com.SpringBoot.MSM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsmApplicationTests {

	@Test
	void contextLoads() {
	}

}
