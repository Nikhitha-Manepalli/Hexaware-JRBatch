import{Route,Routes} from 'react-router-dom';
import './App.css';
import Home from './Components/Home';
import Navbar from './Components/Navbar';

import AddCustomer from './Components/AddCustomer';
import Login from './Components/Login';
import CustomerLogin from './Components/CustomerLogin';
import AddMedicines from './Components/AddMedicines';
import AddPurchase from './Components/AddPurchase';
import ViewCustomer from './Components/ViewCustomer';
import ViewMedicines from './Components/ViewMedicines';
import ViewPurchase from './Components/ViewPurchase';
import BookMedicine from './Components/BookMedicine';
import Payment from './Components/Payment';
import Start from './Components/Start';

import CustHome from './Components/CustHome';


function App() {
  return (
    <div className='bg-div'>
    <Navbar/>
     
      <Routes>
        <Route path='/' element={<Login/>}></Route>
        <Route path='/Home' element={<Home/>}></Route>
        <Route path='/addCustomer' element={<AddCustomer/>}></Route>
        <Route path='/ViewCustomer' element={<ViewCustomer/>}></Route>
        <Route path='/addMedicines' element={<AddMedicines/>}></Route>
        <Route path='/addPurchase' element={<AddPurchase/>}></Route>
        <Route path='/ViewMedicines' element={<ViewMedicines/>}></Route>
        <Route path='/ViewPurchase' element={<ViewPurchase/>}></Route>
        <Route path='/BookMedicine' element={<BookMedicine/>}></Route>
        <Route path='/Payment' element={<Payment/>}></Route>
        <Route path='/CustHome' element={<CustHome/>}></Route>


        <Route path='/CustomerLogin' element={<CustomerLogin/>}></Route>
        
        <Route path='/Start' element={<Start/>}></Route>



      </Routes>
    </div>
  );
}
export default App;
