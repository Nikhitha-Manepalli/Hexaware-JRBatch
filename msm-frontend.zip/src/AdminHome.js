import React, { Component } from 'react';
import{Route,Routes} from 'react-router-dom';
import './App.css';
import Home from './Components/Home';
import AddCustomer from './Components/AddCustomer';
import Login from './Components/Login';
import AddMedicines from './Components/AddCustomer';
import AddPurchase from './Components/AddPurchase';
import ViewCustomer from './Components/ViewCustomer';
import ViewMedicines from './Components/ViewMedicines';
import ViewPurchase from './Components/ViewPurchase';
import BookMedicine from './Components/BookMedicine';
import Payment from './Components/Payment';


class AdminHome extends Component {
    render() {
        return (
            <div>
                
                <Routes>
                <Route path='/' element={<Home/>}></Route>
                <Route path='/addCustomer' element={<AddCustomer/>}></Route>
                <Route path='/ViewCustomer' element={<ViewCustomer/>}></Route>
                <Route path='/addMedicines' element={<AddMedicines/>}></Route>
                <Route path='/addPurchase' element={<AddPurchase/>}></Route>
                <Route path='/ViewMedicines' element={<ViewMedicines/>}></Route>
                <Route path='/ViewPurchase' element={<ViewPurchase/>}></Route>
                <Route path='/BookMedicine' element={<BookMedicine/>}></Route>
                <Route path='/Payment' element={<Payment/>}></Route>



            </Routes>
            </div>
        );
    }
}

export default AdminHome;