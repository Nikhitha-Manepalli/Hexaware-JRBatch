import React, { Component } from 'react';
import{Route,Routes} from 'react-router-dom';
import './App.css';
import CustHome from './Components/CustHome';
import Login from './Components/Login';
import ViewCustomer from './Components/ViewCustomer';
import ViewMedicines from './Components/ViewMedicines';
import ViewPurchase from './Components/ViewPurchase';
import BookMedicine from './Components/BookMedicine';
import Payment from './Components/Payment';


class CustomerHome extends Component {
    render() {
        return (
            <div>
                
                <Routes>
                <Route path='/' element={<CustHome/>}></Route>
                <Route path='/ViewCustomer' element={<ViewCustomer/>}></Route>
                <Route path='/ViewMedicines' element={<ViewMedicines/>}></Route>
                <Route path='/ViewPurchase' element={<ViewPurchase/>}></Route>
                <Route path='/BookMedicine' element={<BookMedicine/>}></Route>
                <Route path='/Payment' element={<Payment/>}></Route>



            </Routes>
            </div>
        );
    }
}

export default CustomerHome;