import axios from "axios";

const API_URL="http://localhost:8081";
class PurchaseService{
    savePurchase(purchase){
        return axios.post(API_URL+"/savePurchase",purchase);
    }
    getAllPurchase()
    {
        return axios.get(API_URL+"/viewPurchase");
    }
     getPurchaseById(id)
     {
        return axios.get(API_URL+"/"+id);
     }
        deletePurchase(purchase_id)
        {
            return axios.get(API_URL+"/deletePurchase/"+purchase_id);
        }   
        editPurchase(purchase)
        {
            return axios.post(API_URL+"/"+purchase.id,purchase);
        } 
}

export default new PurchaseService;