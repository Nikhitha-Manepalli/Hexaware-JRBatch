import React, { Component } from 'react';
import axios from 'axios';
const API_URL="http://localhost:8081";
class MedicinesService{
    
 saveMedicines(medicines){
        return axios.post(API_URL+"/saveMedicines",medicines);
    }
    getAllMedicines()
    {
        return axios.get(API_URL+"/viewMedicines");
    }
     getMedicinesById(med_id)
     {
        return axios.get(API_URL+"/"+med_id);
     }
        deleteMedicines(med_id)
        {
            return axios.get(API_URL+"/deleteMedicines/"+med_id);
        }   
        editMedicines(medicines)
        {
            return axios.post(API_URL+"/updateMedicines"+medicines.med_id,medicines);
        } 

}

export default new MedicinesService;