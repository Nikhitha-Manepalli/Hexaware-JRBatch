import axios from "axios";

const API_URL="http://localhost:8081";
class CustomerService{
    saveCustomer(customer){
        return axios.post(API_URL+"/saveCustomer",customer);
    }
    loginCustomer(loginInfo){
        return axios.post(API_URL+"/login/", loginInfo);
    }
    getAllCustomer()
    {
        return axios.get(API_URL+"/viewCustomer");
    }
     getCustomerById(id)
     {
        return axios.get(API_URL+"/"+id);
     }
        deleteCustomer(id)
        {
            return axios.get(API_URL+"/delete/"+id);
        }   
        editCustomer(customer)
        {
            return axios.post(API_URL+"/"+customer.id,customer);
        } 
        

}
export default new CustomerService;