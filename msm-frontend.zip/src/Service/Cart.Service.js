import React, { Component } from 'react';
import axios from 'axios';
const API_URL="http://localhost:8081";
class CartService{
    
 addCart(cart){
    console.log(cart.medicine_id);
        return axios.post(API_URL+"/addCart",cart);
    }
    
     getCartByMail(mail)
     {
        return axios.get(API_URL+"/"+mail);
     }
        deleteCart(cart)
        {
            return axios.get(API_URL+"/deleteCart/",cart);
        }   
        
}

export default new CartService;