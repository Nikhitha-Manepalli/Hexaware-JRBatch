import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import customerService from "../Service/customer.service";
const ViewCustomer = () => {
  const [customerList, setCustomerList] = useState([]);
  const [msg, setMsg] = useState("");
  useEffect(() => {
    init();
  }, []);
  const init = () => {
    customerService
      .getAllCustomer()
      .then((res) => {
        setCustomerList(res.data);
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const deleteCustomer = (id) => {
    customerService
      .deleteCustomer(id)
      .then((res) => {
        setMsg("Delete Sucessfully");
        init();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card">
              <div className="card-header fs-3 text-center">
                All Customer List
                {msg && <p className="fs-4 text-center text-success">{msg}</p>}
              </div>

              <div className="card-body">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">Id</th>
                      <th scope="col">Password</th>
                      <th scope="col">Firstname</th>
                      <th scope="col">Lastname</th>
                      <th scope="col">Age</th>
                      <th scope="col">Sex</th>
                      <th scope="col">Phno</th>
                      <th scope="col">Mail</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customerList.map((c, num) => (
                      <tr>
                        <td>{num+1}</td>
                        <td>{c.password}</td>
                        <td>{c.firstname}</td>
                        <td>{c.lastname}</td>
                        <td>{c.age}</td>
                        <td>{c.sex}</td>
                        <td>{c.phno}</td>
                        <td>{c.mail}</td>
                        <td>
                          <button
                            onClick={() => deleteCustomer(c.id)}
                            className="btn btn-sm btn-danger ms-1"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewCustomer;