import React from 'react'
function PrivateRout(){
    return(
        <div>PrivateRoute</div>

    )
}
export default PrivateRoute