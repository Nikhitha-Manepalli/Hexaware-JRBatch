import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import medicinesService from "../Service/Medicines.Service";
import CartService from "../Service/Cart.Service";
import Payment from "./Payment";
const BookMedicine = () => {
  const [medicinesList, setMedicinesList] = useState([]);
  const [msg, setMsg] = useState("");
  useEffect(() => {
    init();
  }, []);
  const init = () => {
    medicinesService
      .getAllMedicines()
      .then((res) => {
        setMedicinesList(res.data);
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
   //AddtoCart
   const [medicines, setMedicines] = useState({
    med_id: "",
    

  });

   
    const [cart, setCart] = useState({
      //id: "",
      medicine_id:"",
      userName: "",
      
  
    });
  

    const CartRegsiter = (e) => {
      alert(e.medicine_id);
      CartService
        .addCart(e)
        .then((res) => {

          alert("cart Added Sucessfully");
          
        })
        .catch((error) => {
          console.log(error);
        });
      
  };
 const  AddtoCart=(med_id)=>{
  setCart({ ...cart, [cart.medicine_id]:med_id});
  setCart({ ...cart, [cart.userName]:"nikki@gmail.com" });
  //cart.medicine_id=med_id;
  //cart.userName="nikki@gmail.com";

    CartRegsiter(cart)
    alert(cart.medicine_id)
    
    alert(med_id);


  }


  

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card">
              <div className="card-header fs-3 text-center">
                All Medicines List
                {msg && <p className="fs-4 text-center text-success">{msg}</p>}
              </div>

              <div className="card-body">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">Med_Id</th>
                      <th scope="col">MedicineName</th>
                      <th scope="col">Category</th>
                      <th scope="col">Med_qty</th>
                      <th scope="col">Med_priceperone</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {medicinesList.map((m, num) => (
                      <tr>
                        <td>{num+1}</td>
                        <td>{m.med_name}</td>
                        <td>{m.category}</td>
                        <td>{m.med_qty}</td>
                        <td>{m.med_priceperone}</td>
                        
                          
                          
                         
                        
                        <td>
                        <Link className="btn btn-success"  onClick={() => AddtoCart(m.med_id)}>Add to cart</Link>

                        <Link className="btn btn-success" to={'/Payment'}>Book medicines</Link>
                        
                         
                        </td>
                        
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookMedicine;