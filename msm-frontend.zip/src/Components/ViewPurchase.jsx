import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import purchaseService from "../Service/purchase.service";
const ViewPurchase = () => {
  const [purchaseList, setPurchaseList] = useState([]);
  const [msg, setMsg] = useState("");
  useEffect(() => {
    init();
  }, []);
  const init = () => {
    purchaseService
      .getAllPurchase()
      .then((res) => {
        setPurchaseList(res.data);
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const deletePurchase = (purchase_id) => {
    purchaseService
      .deletePurchase(purchase_id)
      .then((res) => {
        setMsg("Deleted Sucessfully");
        init();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card">
              <div className="card-header fs-3 text-center">
                All Purchase List
                {msg && <p className="fs-4 text-center text-success">{msg}</p>}
              </div>

              <div className="card-body">
                <table class="table">
                  <thead>
                    <tr>
                    <th scope="col">Purchase_id</th>
                      <th scope="col">Item_name</th>
                      <th scope="col">Quantity</th>
                      <th scope="col">Price_per_unit</th>
                      <th scope="col">Total_cost</th>
                      <th scope="col">Purchase_date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {purchaseList.map((p, num) => (
                      <tr>
                        <td>{num+1}</td>
                        <td>{p.item_name}</td>
                        <td>{p.quantity}</td>
                        <td>{p.price_per_unit}</td>
                        <td>{p.total_cost}</td>
                        <td>{p.purchase_date}</td>
                        
                        <td>
                          <button
                            onClick={() => deletePurchase(p.purchase_id)}
                            className="btn btn-sm btn-danger ms-1"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewPurchase;