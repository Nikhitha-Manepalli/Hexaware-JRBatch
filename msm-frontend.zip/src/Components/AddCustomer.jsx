import React, { useState } from "react";
import CustomerService from "../Service/customer.service";
import { useNavigate } from "react-router-dom";
const AddCustomer = () => {
  const [customer, setCustomer] = useState({
    id: "",
    password: "",
    firstname: "",
    lastname: "",
    age: "",
    sex: "",
    phno:"",
    mail:"",
  });

  const nav = useNavigate();

  const [msg, setMsg] = useState("");

  const handleChange = (e) => {
    const value = e.target.value;

    setCustomer({ ...customer, [e.target.name]: value });
    console.log(customer);
  };

  const CustomerRegsiter = (e) => {
    e.preventDefault();
    const validatePassword  = new RegExp("[A-Za-z0-9]");
    const validateemail  = new RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$");

    

    if(customer.id.length===0){
      alert("Id can't be null");
    }else if(customer.password.length===0){
      alert("paswword can't be null");
    }
    else if(!validatePassword.test(customer.password)){
      alert("password must contain letters or numbers");
  }
    else if(customer.firstname.length===0){
      alert("firstname can't be null");
    } else if(customer.lastname.length===0){
      alert("lastname can't be null");
    } else if(customer.age.length===0){
      alert("age can't be null");
    } else if(customer.sex.length===0){
      alert("sex can't be null");
    }
    else if(customer.phno.length===0){
      alert("phno can't be null");
    } else if(customer.mail.length===0){
      alert("mail can't be null");
    }
    else if(!validateemail.test(customer.mail)){
      alert("mail must contain @ symbol");
  }else{
      CustomerService
      .saveCustomer(customer)
      .then((res) => {
        if(res.data != null){
          alert("Registration Successfull");
          nav('/');
        }
        console.log("Customer Registered Sucessfully");
        console.log(customer);
        setMsg("Customer Registered Sucessfully");
        console.log(res);
        
      })
      .catch((error) => {
        console.log(error);
      });

    }
    /*setCustomer({
      id:customer.id,
      password:customer.password,
      firstname: customer.firstname,
      lastname: customer.lastname,
      age: customer.age,
      sex:customer.sex,
      phno:customer.phno,
      mail:customer.mail,
  });*/

   
  };

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <div className="card">
              <div className="card-header fs-3 text-center">Customer Registration</div>
              {msg && <p className="fs-4 text-center text-success">{msg}</p>}

              <div className="card-body">
                <form onSubmit={(e) => CustomerRegsiter(e)}>
                  <div className="mb-3">
                    <label>Enter Id</label>
                    <input
                      type="number"
                      name="id"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.id}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Enter Password </label>
                    <input
                      type="text"
                      name="password"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.password}
                    />
                  </div>
                  <div className="mb-3">
                    <label>Enter Firstname</label>
                    <input
                      type="text"
                      name="firstname"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.firstname}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Enter Lastname</label>
                    <input
                      type="text"
                      name="lastname"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.lastname}
                    />
                    </div>
                    <div className="mb-3">
                    <label>Enter Age</label>
                    <input
                      type="number"
                      name="age"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.age}
                    />
                    </div>
                     <div className="mb-3">
                    <label>Enter Sex</label>
                    <input
                      type="text"
                      name="sex"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.sex}
                    />
                  </div>
                  <div className="mb-3">
                    <label>Enter Phno</label>
                    <input
                      type="text"
                      name="phno"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.phno}
                    />
                    </div>
                    <div className="mb-3">
                    <label>Enter Mail</label>
                    <input
                      type="text"
                      name="mail"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={customer.mail}
                    />
                    </div>
                  <button className="btn btn-primary col-md-12">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddCustomer;