import React, { useState } from "react";
import PurchaseService from '../Service/purchase.service';
import { useNavigate } from "react-router-dom";

const AddPurchase = () => {
  const [purchase, setPurchase] = useState({
    purchase_id: "",
    item_name: "",
    quantity: "",
    price_per_unit: "",
    total_cost: "",
    purchase_date: "",
  });
  
  const nav = useNavigate();

  const [msg, setMsg] = useState("");

  const handleChange = (e) => {
    const value = e.target.value;

    setPurchase({ ...purchase, [e.target.name]: value });
    console.log(purchase);
  };

  const PurchaseRegsiter = (e) => {
    e.preventDefault();
    
  if(purchase.purchase_id.length===0){
    alert("Id can't be null");
  }else if(purchase.item_name.length===0){
    alert("Medicine_name can't be null");
  }
  else if( purchase.quantity.length===0){
    alert("Quantity can't be null");
  } else if(purchase.price_per_unit.length===0){
    alert("Price can't be null");
  } else if(purchase.total_cost.length===0){
    alert("cost can't be null");
  } else if(purchase.purchase_date.length===0){
    alert("Date can't be null");
  }
  else{

    PurchaseService
      .savePurchase(purchase)
      .then((res) => {
        if(res.data != null){
          alert("purchase details added Successfull");
          nav('/Home');
        }

        
        setMsg("Purchase Added Sucessfully");
        console.log(res);
        
      })
      .catch((error) => {
        console.log(error);
      });
    }
  };

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <div className="card">
              <div className="card-header fs-3 text-center">Add Purchase</div>
              {msg && <p className="fs-4 text-center text-success">{msg}</p>}

              <div className="card-body">
                <form onSubmit={(e) => PurchaseRegsiter(e)}>
                  <div className="mb-3">
                    <label>Enter Id</label>
                    <input
                      type="number"
                      name="purchase_id"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={purchase.purchase_id}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Enter medicine </label>
                    <input
                      type="text"
                      name="item_name"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={purchase.item_name}
                    />
                  </div>
                  <div className="mb-3">
                    <label>Enter Quantity</label>
                    <input
                      type="number"
                      name="quantity"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={purchase.quantity}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Enter price_per_one</label>
                    <input
                      type="number"
                      name="price_per_unit"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={purchase.price_per_unit}
                    />
                    </div>
                    <div className="mb-3">
                    <label>Enter total_cost</label>
                    <input
                      type="number"
                      name="total_cost"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={purchase.total_cost}
                    />
                    </div>
                     <div className="mb-3">
                    <label>Enter Date</label>
                    <input
                      type="text"
                      name="purchase_date"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={purchase.purchase_date}
                    />
                  </div>
                  <button className="btn btn-primary col-md-12">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddPurchase;