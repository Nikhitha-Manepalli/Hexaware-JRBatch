import React from 'react';
import "./css/style.css";
import { Link , useNavigate} from 'react-router-dom'
import { useState } from "react";
import CustomerService from "../Service/customer.service";



const Login = () =>{


    const [loginInfo, setCustomer_login] = useState({
        password: "",
        mail:"",
      });

      const navigate = useNavigate();
    
      const [msg, setMsg] = useState("");
    
      const handleChange = (e) => {
        const value = e.target.value;
    
        setCustomer_login({ ...loginInfo, [e.target.name]: value });
        console.log(loginInfo);
      };
    
      const login_customer = (e) => {
        e.preventDefault();

        const validatePassword  = new RegExp("[A-Za-z0-9]");
        if(loginInfo.mail.length === 0){
            setMsg("EMail can't be Empty!")
        }else if(loginInfo.password.length === 0){
            setMsg("Password can't be Empty!")
        }else if(!validatePassword.test(loginInfo.password)){
            setMsg("Please Enter a valid Password");
        }else{  
            setMsg("");
            setCustomer_login({
                password:loginInfo.password,
                mail:loginInfo.mail
            });

                CustomerService
            .loginCustomer(loginInfo)
            .then((res) => {
                if(res.data[0] == null){
                    setMsg("Please Check your Login information!");
                }else{
                    navigate('/Home');
                    //setMsg("Success!");
                }
                console.log(res);
                
            })
            .catch((error) => {
                console.log(error);
            });

            console.log(loginInfo);
        }
    
        
      };
    
        return (
            <div className='container mt-1 border-2 bg-light shadow p-5'>
                <h3 className='text-center'>Login</h3>
                {msg && <p className="fs-4 text-center text-danger">{msg}</p>}
               <form onSubmit={(e) => login_customer(e)} method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" name = "mail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" 
                        onChange={(e) => handleChange(e)}
                        value={loginInfo.mail}/>
                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" 
                    class="form-control" id="exampleInputPassword1" 
                    onChange={(e) => handleChange(e)}
                    value={loginInfo.password}/>
                </div>
                <div className='text-center'>
                <input type="submit" className="btn btn-success" value={"Login"}/>
                {/* <Link className="btn btn-success" to={'/Home'}>Login</Link>                  */}
                </div>
                </form>

                
            </div>
        );
    }

export default Login;