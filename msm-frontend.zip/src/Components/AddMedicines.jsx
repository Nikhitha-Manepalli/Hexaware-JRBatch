import React, { useState } from "react";
import MedicinesService from "../Service/Medicines.Service";
const AddMedicines = () => {
  const [medicines, setMedicines] = useState({
    med_id: "",
    med_name: "",
    med_qty: "",
    category: "",
    med_priceperone: "",

  });

  const [msg, setMsg] = useState("");

  const handleChange = (e) => {
    const value = e.target.value;
    setMedicines({ ...medicines, [e.target.name]: value });
  };

  const MedicinesRegsiter = (e) => {
    e.preventDefault();
    if(medicines.med_id.length===0){
      alert("Id can't be null");
    }else if(medicines.med_name.length===0){
      alert("Medicine_name can't be null");
    }
    else if( medicines.med_qty.length===0){
      alert("Quantity can't be null");
    } else if(medicines.category.length===0){
      alert("Category can't be null");
    } else if(medicines.med_priceperone.length===0){
      alert("price can't be null");
    } 
    else{

    MedicinesService
      .saveMedicines(medicines)
      .then((res) => {
        console.log("medicines Added Sucessfully");
        setMsg("medicines Added Sucessfully");
        
      })
      .catch((error) => {
        console.log(error);
      });
    }
};

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <div className="card">
              <div className="card-header fs-3 text-center">Add Medicines</div>
              {msg && <p className="fs-4 text-center text-success">{msg}</p>}

              <div className="card-body">
                <form onSubmit={(e) => MedicinesRegsiter(e)}>
                  <div className="mb-3">
                    <label>Enter Medicine Id</label>
                    <input
                      type="number"
                      name="med_id"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={medicines.med_id}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Enter medicine name </label>
                    <input
                      type="text"
                      name="med_name"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={medicines.med_name}
                    />
                  </div>
                  <div className="mb-3">
                    <label>Enter medicine quantity</label>
                    <input
                      type="number"
                      name="med_qty"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={medicines.med_qty}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Enter category</label>
                    <input
                      type="text"
                      name="category"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={medicines.category}
                    />
                    </div>
                    <div className="mb-3">
                    <label>Enter price</label>
                    <input
                      type="number"
                      name="med_priceperone"
                      className="form-control"
                      onChange={(e) => handleChange(e)}
                      value={medicines.med_priceperone}
                    />
                    </div>
                  <button className="btn btn-primary col-md-12">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddMedicines;