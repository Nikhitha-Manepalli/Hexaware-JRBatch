import React from 'react'
import { Link } from 'react-router-dom'

 const Payment=()=>{
    
    return(
        
        alert("payment Succesfull!.....")

        
    )
 }
 export default Payment;
 