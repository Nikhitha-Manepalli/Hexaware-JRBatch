import React from 'react'
import { Link} from 'react-router-dom'


function Start(){
    return(
        <div className='d-flex justify-content-center align-items-center vh-100 loginPage'>
            <div className='p-3 rounded w-25 border loginForm'>
                <h2> Login As</h2>
                <div className='d-flex justify-content-around mt-3'>
                
                <Link className="btn btn-success" to={'/CustomerLogin'}>Customer</Link>
                <Link className="btn btn-success" to={'/'}>Admin</Link> 
                    

                </div>
            </div>
        </div>
    )
}


export default Start;