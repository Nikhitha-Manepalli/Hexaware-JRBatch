import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import medicinesService from "../Service/Medicines.Service";

const ViewMedicines = () => {
  const [medicinesList, setMedicinesList] = useState([]);
  const [msg, setMsg] = useState("");
  useEffect(() => {
    init();
  }, []);
  const init = () => {
    medicinesService
      .getAllMedicines()
      .then((res) => {
        setMedicinesList(res.data);
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const deleteMedicines = (med_id) => {
    medicinesService
      .deleteMedicines(med_id)
      .then((res) => {
        setMsg("Deleted Sucessfully");
        init();
      })
      .catch((error) => {
        console.log(error);
      });
  };
  

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card">
              <div className="card-header fs-3 text-center">
                All Medicines List
                {msg && <p className="fs-4 text-center text-success">{msg}</p>}
              </div>

              <div className="card-body">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">Med_Id</th>
                      <th scope="col">MedicineName</th>
                      <th scope="col">Category</th>
                      <th scope="col">Med_qty</th>
                      <th scope="col">Med_priceperone</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {medicinesList.map((m, num) => (
                      <tr>
                        <td>{num+1}</td>
                        <td>{m.med_name}</td>
                        <td>{m.category}</td>
                        <td>{m.med_qty}</td>
                        <td>{m.med_priceperone}</td>

                        
                        <td>
                        

                          <button
                            onClick={() => deleteMedicines(m.med_id)}
                            className="btn btn-sm btn-danger ms-1"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewMedicines;