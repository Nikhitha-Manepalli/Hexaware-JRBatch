import React from 'react'
import { Link } from 'react-router-dom'
import ViewCustomer from './ViewCustomer'
import customerService from '../Service/customer.service'
 const CustHome=()=>{
    return(
        <>
        <div class="text-center"><h1>Medical Store Management System</h1></div>
        <div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card w-50">
      <div class="card-body">
        <h5 class="card-title">Customers</h5>
        <p class="card-text">you can view customers here!!.</p>
        <Link className="btn btn-success" to={'/ViewCustomer'}>View customers</Link>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card w-50">
      <div class="card-body">
        <h5 class="card-title">Medicines</h5>
        <p class="card-text">you can view medicines here!!.</p>
        <Link className="btn btn-success" to={'/ViewMedicines'}>View Medicines</Link>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card w-50">
      <div class="card-body">
        <h5 class="card-title">Purchase</h5>
        <p class="card-text">you can view purchases here!!.</p>
        <Link className="btn btn-success" to={'/ViewPurchase'}>View Purchases</Link>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card w-50">
      <div class="card-body">
        <h5 class="card-title">Book Medicines</h5>
        <p class="card-text">you can book medicines here!!.</p>
        <Link className="btn btn-success" to={'/BookMedicine'}>Book Medicines</Link>
      </div>
    </div>
  </div>
</div>
            
            
        
        </>
    )
 }
 export default CustHome;