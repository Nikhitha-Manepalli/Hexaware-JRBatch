package com.backbase.message.mapper;

import com.backbase.dbs.messaging_service.api.service.v2.model.MessageItem;
import com.backbase.message.model.Greeting;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface GreetingsMapper {

    GreetingsMapper INSTANCE = Mappers.getMapper(GreetingsMapper.class);

    // Converts Greeting -> MessageItem
    MessageItem greetingToMessageItem(Greeting greeting);

    // Converts List<Greeting> -> List<MessageItem>
    List<MessageItem> greetingsToMessageItems(List<Greeting> greetings);

    // Converts MessageItem -> Greeting
    Greeting messageItemToGreeting(MessageItem messageItem);
}
