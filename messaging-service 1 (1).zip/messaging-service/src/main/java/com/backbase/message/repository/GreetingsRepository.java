package com.backbase.message.repository;

import com.backbase.message.model.Greeting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GreetingsRepository extends JpaRepository<Greeting, String> {

    @Override
    List<Greeting> findAll();
}