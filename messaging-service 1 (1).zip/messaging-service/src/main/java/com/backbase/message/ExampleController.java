package com.backbase.message;


import com.backbase.dbs.messaging_service.api.service.v2.MessageApi;
import com.backbase.dbs.messaging_service.api.service.v2.model.MessageId;
import com.backbase.dbs.messaging_service.api.service.v2.model.MessageItem;
import com.backbase.message.model.Greeting;
import com.backbase.message.mapper.GreetingsMapper;
import com.backbase.message.service.GreetingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@RestController
public class ExampleController implements MessageApi{

    @Autowired
    private GreetingsService greetingsService;

    @RequestMapping(method = RequestMethod.GET, value = "/message", produces = {
            "application/json"
    })
    @ResponseStatus(HttpStatus.OK)
    public MessageItem getMessage() {
        // Example implementation, you can modify as needed
        return new MessageItem().message("Hello World");
    }

    @Override
    public ResponseEntity<Void> deleteMessage(String id) {
        Greeting greeting = greetingsService.getGreetingById(id);
        greetingsService.deleteGreeting(greeting);
        return ResponseEntity.noContent().build();
    }

    @Override
    public ResponseEntity<MessageItem> getMessage(String id) {
        Greeting greeting = greetingsService.getGreetingById(id);
        return ResponseEntity.ok(GreetingsMapper.INSTANCE.greetingToMessageItem(greeting));
    }

    @Override
    public ResponseEntity<List<MessageItem>> getMessages() {
        List<Greeting> greetings = greetingsService.getGreetings();
        return ResponseEntity.ok(GreetingsMapper.INSTANCE.greetingsToMessageItems(greetings));
    }



    @Override
    public ResponseEntity<MessageId> postMessage(MessageItem body) {
        Greeting greeting = GreetingsMapper.INSTANCE.messageItemToGreeting(body);
        greetingsService.saveGreeting(greeting);
        return ResponseEntity.status(HttpStatus.CREATED).body(new MessageId().id(greeting.getId()));
    }

    @Override
    public ResponseEntity<Void> putMessage(MessageItem body) {
        Greeting greeting = greetingsService.getGreetingById(body.getId());
        greeting.setMessage(body.getMessage());
        greetingsService.saveGreeting(greeting);
        return ResponseEntity.noContent().build();
    }
}